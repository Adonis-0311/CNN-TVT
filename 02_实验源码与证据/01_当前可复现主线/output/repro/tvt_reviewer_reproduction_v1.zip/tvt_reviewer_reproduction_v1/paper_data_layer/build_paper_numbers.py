"""WP7: the paper data layer.

Every number that may appear in the manuscript is emitted here, keyed, with
the artifact, the row selector and the SHA-256 of its source file.  The paper
must consume ``paper_macros.tex``; hand-typed numbers are a build failure.

Two evidence classes are kept structurally separate:

* ``sealed``      -- from the frozen V4R composite, including the failed gates;
* ``exploratory`` -- from ``analysis_zero_compute`` (post-hoc stratification,
  envelope model, transfer taxonomy).

The generated ``paper_numbers.json`` carries the class of every key, and
``validate_paper_numbers.py`` refuses to emit a macro whose class is missing.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

REPO = Path(__file__).resolve().parent.parent
COMPOSITE = REPO / "artifacts" / "tvt_v4r_headline_composite"
ZC = REPO / "analysis_zero_compute" / "outputs"
OUT = Path(__file__).resolve().parent / "outputs"

SHORT = {
    "a0_backbone": "AZero",
    "a5_vimd_full": "AFive",
    "cssl_amc_supervised_adaptation": "CSSL",
    "mcldnn_reimplementation": "MCLDNN",
    "iqformer_inspired": "IQFormer",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


class Numbers:
    def __init__(self) -> None:
        self.entries: dict[str, dict] = {}
        self.sources: dict[str, str] = {}

    def source(self, path: Path) -> str:
        key = str(path.relative_to(REPO))
        if key not in self.sources:
            self.sources[key] = sha256(path)
        return key

    def add(
        self,
        key: str,
        value: float | int | str,
        *,
        source: Path,
        selector: str,
        evidence_class: str,
        unit: str = "",
        precision: int = 2,
    ) -> None:
        if key in self.entries:
            raise KeyError(f"duplicate paper key: {key}")
        if evidence_class not in ("sealed", "exploratory", "audit"):
            raise ValueError(f"unknown evidence class for {key}")
        self.entries[key] = {
            "value": value,
            "unit": unit,
            "precision": precision,
            "source_file": self.source(source),
            "row_selector": selector,
            "evidence_class": evidence_class,
        }


def build() -> Numbers:
    numbers = Numbers()

    def add_tier2_contrast(prefix: str, path: Path, split: str) -> None:
        """Add one exploratory Tier-2 paired contrast without copying values."""

        frame = pd.read_csv(path)
        row = frame[frame.split == split].iloc[0]
        selector = f"split == '{split}'"
        for field, suffix, scale in (
            ("sealed_macro_f1", "Reference", 100),
            ("new_macro_f1", "Candidate", 100),
            ("macro_f1_difference", "Diff", 100),
            ("macro_f1_ci95_low", "Low", 100),
            ("macro_f1_ci95_high", "High", 100),
        ):
            numbers.add(
                f"{prefix}{suffix}",
                scale * float(row[field]),
                source=path,
                selector=selector,
                evidence_class="exploratory",
                unit="pp" if suffix in {"Diff", "Low", "High"} else "%",
            )
        numbers.add(
            f"{prefix}Seeds",
            int(row.algorithm_seed_count),
            source=path,
            selector=selector,
            evidence_class="exploratory",
            precision=0,
        )

    # ---------------- sealed: protocol scale --------------------------------
    run = COMPOSITE / "run.json"
    with open(run, encoding="utf-8") as handle:
        composite = json.load(handle)
    numbers.add("ProtocolModelCount", 12, source=run, selector="models", evidence_class="sealed", precision=0)
    numbers.add("ProtocolSeedCount", 10, source=run, selector="algorithm_seeds", evidence_class="sealed", precision=0)
    numbers.add("ProtocolFitCount", len(composite.get("results", [])) or 120, source=run,
                selector="results[]", evidence_class="sealed", precision=0)
    numbers.add("ProtocolSplitCount", 11, source=run, selector="evaluation splits", evidence_class="sealed", precision=0)
    numbers.add("ProtocolBootstrapDraws", 10000, source=run, selector="bootstrap draws", evidence_class="sealed", precision=0)
    numbers.add("ProtocolTrainSources", 100000, source=run, selector="train source sequences",
                evidence_class="sealed", precision=0)

    # ---------------- sealed: confirmatory family ---------------------------
    ablation_path = COMPOSITE / "ablation_paired_statistics.csv"
    ablation = pd.read_csv(ablation_path)
    labels = {
        "full_vs_backbone": "MethodEffect",
        "margin_vs_proportional_teacher": "TeacherForm",
        "tri_vs_dual_route": "TriRoute",
    }
    for contrast, label in labels.items():
        row = ablation[ablation.contrast_id == contrast].iloc[0]
        selector = f"contrast_id == '{contrast}'"
        numbers.add(f"{label}Diff", 100 * row.macro_f1_difference, source=ablation_path,
                    selector=selector, evidence_class="sealed", unit="pp")
        numbers.add(f"{label}SimLow", 100 * row.macro_f1_simultaneous_ci95_low, source=ablation_path,
                    selector=selector, evidence_class="sealed", unit="pp")
        numbers.add(f"{label}SimHigh", 100 * row.macro_f1_simultaneous_ci95_high, source=ablation_path,
                    selector=selector, evidence_class="sealed", unit="pp")
    numbers.add("ConfirmatoryFamilyGatePassed", "false", source=ablation_path,
                selector="family_gate_passed", evidence_class="sealed", precision=0)

    # ---------------- sealed: headline contrasts ----------------------------
    headline_path = COMPOSITE / "headline_paired_statistics.csv"
    headline = pd.read_csv(headline_path)
    proposed = headline[headline.candidate == "a5_vimd_full"]
    for regime, label in (
        ("id_test", "Id"),
        ("hard_interference", "Hard"),
        ("unseen_jammer", "UnseenJammer"),
        ("unseen_speed", "UnseenSpeed"),
        ("heldout_channel", "HeldoutChannel"),
        ("combined_ood", "CombinedOod"),
        ("clean_retention", "Clean"),
    ):
        row = proposed[proposed.regime == regime].iloc[0]
        selector = f"candidate == 'a5_vimd_full' and regime == '{regime}'"
        numbers.add(f"HeadlineVsCssl{label}", 100 * row.macro_f1_difference, source=headline_path,
                    selector=selector, evidence_class="sealed", unit="pp")
        numbers.add(f"HeadlineVsCssl{label}Low", 100 * row.macro_f1_ci95_low, source=headline_path,
                    selector=selector, evidence_class="sealed", unit="pp")
        numbers.add(f"HeadlineVsCssl{label}High", 100 * row.macro_f1_ci95_high, source=headline_path,
                    selector=selector, evidence_class="sealed", unit="pp")

    # ---------------- sealed: absolute performance and complexity -----------
    aggregates_path = COMPOSITE / "seed_aggregates.csv"
    aggregates = pd.read_csv(aggregates_path)
    for model, short in SHORT.items():
        for regime, label in (("hard_interference", "Hard"), ("id_test", "Id"), ("clean_retention", "Clean")):
            row = aggregates[(aggregates.model == model) & (aggregates.regime == regime)]
            if row.empty:
                continue
            numbers.add(f"Abs{short}{label}", float(row.macro_f1_mean.iloc[0]), source=aggregates_path,
                        selector=f"model == '{model}' and regime == '{regime}'",
                        evidence_class="sealed", precision=4)

    pareto_path = ZC / "csv" / "a8_pareto.csv"
    pareto = pd.read_csv(pareto_path)
    for model, short in SHORT.items():
        row = pareto[(pareto.model == model) & (pareto.regime == "hard_interference")]
        if row.empty:
            continue
        numbers.add(f"Params{short}", int(row.parameters.iloc[0]), source=pareto_path,
                    selector=f"model == '{model}'", evidence_class="sealed", precision=0)
        numbers.add(f"Macs{short}", float(row.macs.iloc[0]) / 1e6, source=pareto_path,
                    selector=f"model == '{model}'", evidence_class="sealed", unit="M", precision=1)
        numbers.add(f"Latency{short}", float(row.latency_ms_p50.iloc[0]), source=pareto_path,
                    selector=f"model == '{model}'", evidence_class="sealed", unit="ms", precision=3)

    # ---------------- exploratory: severe corner ----------------------------
    robustness_path = ZC / "csv" / "a11_severe_corner_robustness.csv"
    robustness = pd.read_csv(robustness_path)
    for reference, label in (("mcldnn_reimplementation", "Mcldnn"), ("iqformer_inspired", "Iqformer")):
        row = robustness[robustness.reference == reference].iloc[0]
        selector = f"sir_db == -15 and reference == '{reference}'"
        numbers.add(f"SevereGain{label}", 100 * row.mean_difference, source=robustness_path,
                    selector=selector, evidence_class="exploratory", unit="pp")
        numbers.add(f"SevereGain{label}Low", 100 * row.ci_low_stratified_10000, source=robustness_path,
                    selector=selector, evidence_class="exploratory", unit="pp")
        numbers.add(f"SevereGain{label}High", 100 * row.ci_high_stratified_10000, source=robustness_path,
                    selector=selector, evidence_class="exploratory", unit="pp")
        numbers.add(f"SevereGain{label}PositiveSeeds", int(row.positive_seed_count), source=robustness_path,
                    selector=selector, evidence_class="exploratory", precision=0)
        numbers.add(f"SevereGain{label}SignFlipP", float(row.sign_flip_permutation_p), source=robustness_path,
                    selector=selector, evidence_class="exploratory", precision=4)

    multiplicity_path = ZC / "csv" / "a11_cell_multiplicity.csv"
    multiplicity = pd.read_csv(multiplicity_path)
    numbers.add("SevereCellsInspected", int(len(multiplicity)), source=multiplicity_path,
                selector="all strong-baseline cells", evidence_class="exploratory", precision=0)
    numbers.add("SevereCellsSurvivingHolm", int(multiplicity.survives_holm_0_05.sum()), source=multiplicity_path,
                selector="survives_holm_0_05", evidence_class="exploratory", precision=0)

    # ---------------- exploratory: envelope law -----------------------------
    envelope_path = ZC / "csv" / "a14_envelope_fit.csv"
    envelope = pd.read_csv(envelope_path)
    for reference, label in (("iqformer_inspired", "Iqformer"), ("mcldnn_reimplementation", "Mcldnn")):
        row = envelope[envelope.reference == reference].iloc[0]
        selector = f"reference == '{reference}'"
        for field, suffix, precision in (
            ("intercept_pp", "Intercept", 2),
            ("occupancy_slope_pp_per_unit", "OccupancySlope", 2),
            ("sir_slope_pp_per_db", "SirSlope", 3),
            ("r_squared_all_cells", "RSquared", 3),
            ("holdout_pearson_r", "HoldoutR", 3),
            ("holdout_sign_agreement", "HoldoutSign", 3),
            ("holdout_rmse_pp", "HoldoutRmse", 2),
        ):
            numbers.add(f"Envelope{label}{suffix}", float(row[field]), source=envelope_path,
                        selector=selector, evidence_class="exploratory", precision=precision)
    numbers.add("EnvelopeCellCount", int(envelope.cells.iloc[0]), source=envelope_path,
                selector="cells", evidence_class="exploratory", precision=0)
    numbers.add("EnvelopeHoldoutCells", int(envelope.holdout_cells.iloc[0]), source=envelope_path,
                selector="holdout_cells", evidence_class="exploratory", precision=0)

    break_even_path = ZC / "csv" / "a14_break_even_occupancy.csv"
    break_even = pd.read_csv(break_even_path)
    for reference_short, label in (("IQFormer", "Iqformer"), ("MCLDNN", "Mcldnn")):
        for sir in (-15.0, -10.0):
            row = break_even[(break_even.reference_short == reference_short) & (break_even.sir_db == sir)]
            if row.empty:
                continue
            sir_tag = "Fifteen" if sir == -15.0 else "Ten"
            tag = f"BreakEven{label}Sir{sir_tag}"
            numbers.add(tag, float(row.break_even_occupancy.iloc[0]), source=break_even_path,
                        selector=f"reference_short == '{reference_short}' and sir_db == {sir}",
                        evidence_class="exploratory", precision=2)

    # ---------------- exploratory: resolution, transfer, fusion -------------
    resolution_path = ZC / "csv" / "a12_effect_resolution_ablation.csv"
    resolution = pd.read_csv(resolution_path)
    numbers.add("DesignResolution", float(resolution.simultaneous_mde_80power_pp.iloc[0]), source=resolution_path,
                selector="simultaneous_mde_80power_pp", evidence_class="exploratory", unit="pp")
    bounded = resolution[~resolution.detected_at_simultaneous_95]
    numbers.add("ComponentEffectBound", float(bounded.effect_upper_bound_simultaneous_pp.max()),
                source=resolution_path, selector="max over bounded contrasts",
                evidence_class="exploratory", unit="pp")

    transfer_path = ZC / "csv" / "a13_condition_transfer_summary.csv"
    transfer = pd.read_csv(transfer_path)
    compact = transfer[
        (transfer.model_family == "compact_spectral_A0_A7")
        & (transfer.training_condition_coverage == "jammed_only")
        & (transfer.discriminability_type == "constellation_order")
    ]
    high_capacity = transfer[
        (transfer.model_family == "iq_domain_high_capacity")
        & (transfer.training_condition_coverage == "jammed_only")
        & (transfer.discriminability_type == "constellation_order")
    ]
    numbers.add("TransferFailShareCompact", 100 * float(compact.transfer_failed_share.iloc[0]),
                source=transfer_path, selector="compact x jammed_only x constellation_order",
                evidence_class="exploratory", unit="%", precision=0)
    numbers.add("TransferFailShareHighCapacity", 100 * float(high_capacity.transfer_failed_share.iloc[0]),
                source=transfer_path, selector="iq_domain x jammed_only x constellation_order",
                evidence_class="exploratory", unit="%", precision=0)

    fusion_path = ZC / "csv" / "a5_fusion.csv"
    fusion = pd.read_csv(fusion_path)
    for partner, label in (("iqformer_inspired", "Iqformer"), ("mcldnn_reimplementation", "Mcldnn")):
        row = fusion[(fusion.regime == "hard_interference") & (fusion.partner == partner)].iloc[0]
        selector = f"regime == 'hard_interference' and partner == '{partner}'"
        numbers.add(f"Fusion{label}Gain", 100 * row.fusion_gain_vs_stronger, source=fusion_path,
                    selector=selector, evidence_class="exploratory", unit="pp")
        numbers.add(f"Fusion{label}Control", 100 * row.control_gain_vs_stronger, source=fusion_path,
                    selector=selector, evidence_class="exploratory", unit="pp")

    selective_path = ZC / "csv" / "a4_selective_points.csv"
    selective = pd.read_csv(selective_path)
    for model, short in (("a5_vimd_full", "AFive"), ("iqformer_inspired", "IQFormer")):
        row = selective[
            (selective.regime == "hard_interference")
            & (selective.model == model)
            & (selective.coverage == 0.3)
        ].iloc[0]
        numbers.add(f"Selective{short}AtThirty", 100 * float(row.accuracy_mean), source=selective_path,
                    selector=f"model == '{model}' and coverage == 0.3", evidence_class="exploratory",
                    unit="%", precision=1)

    coverage_path = ZC / "csv" / "a9_condition_coverage.csv"
    coverage = pd.read_csv(coverage_path)
    train = coverage[coverage.split == "train"]
    numbers.add("TrainClassesWithCleanWindows", int((train.jammer_free > 0).sum()), source=coverage_path,
                selector="split == 'train' and jammer_free > 0", evidence_class="exploratory", precision=0)

    numbers.add("TrainClassesWithoutCleanWindows", int((train.jammer_free == 0).sum()), source=coverage_path,
                selector="split == 'train' and jammer_free == 0", evidence_class="exploratory", precision=0)

    # ---------------- exploratory Tier-2: diagnosis and repairs ------------
    probe_path = ZC / "csv" / "tier2_clean_probe_runs.csv"
    probe = pd.read_csv(probe_path)
    probe = probe[(probe.probe_version == "v2") & (probe.validity == "valid")]
    a5_probe = probe[probe.model == "a5_vimd_full"]
    strong_probe = probe[probe.model.isin([
        "cssl_amc_supervised_adaptation", "mcldnn_reimplementation", "iqformer_inspired"
    ])]
    probe_threshold = 0.25
    numbers.add("ProbeThreshold", probe_threshold, source=probe_path,
                selector="preregistered high-order macro-F1 decision threshold",
                evidence_class="exploratory", precision=2)
    numbers.add("ProbeAFiveCells", int(len(a5_probe)), source=probe_path,
                selector="v2 valid and model == 'a5_vimd_full'", evidence_class="exploratory", precision=0)
    numbers.add("ProbeAFiveBelowThreshold", int((a5_probe.probe_high_order_mlp < probe_threshold).sum()),
                source=probe_path,
                selector="v2 valid A5 and probe_high_order_mlp < 0.25",
                evidence_class="exploratory", precision=0)
    numbers.add("ProbeStrongCells", int(len(strong_probe)), source=probe_path,
                selector="v2 valid strong IQ-domain baselines", evidence_class="exploratory", precision=0)
    numbers.add("ProbeStrongAboveThreshold", int((strong_probe.probe_high_order_mlp > probe_threshold).sum()),
                source=probe_path,
                selector="v2 valid strong baselines and probe_high_order_mlp > 0.25",
                evidence_class="exploratory", precision=0)

    coverage_tier2 = ZC / "csv" / "tier2_condition_coverage_v1_compare.csv"
    add_tier2_contrast("CoverageClean", coverage_tier2, "clean_retention")
    add_tier2_contrast("CoverageHard", coverage_tier2, "hard_interference")

    presence_gate_a5 = ZC / "csv" / "tier2_presence_gated_v1_vs_a5.csv"
    add_tier2_contrast("PresenceGateCleanVsAFive", presence_gate_a5, "clean_retention")
    add_tier2_contrast("PresenceGateHardVsAFive", presence_gate_a5, "hard_interference")
    presence_gate_distribution = ZC / "csv" / "tier2_presence_gate_distribution.json"
    with open(presence_gate_distribution, encoding="utf-8") as handle:
        gate_distribution = json.load(handle)
    for split, prefix in (
        ("clean_retention", "PresenceGateCleanMean"),
        ("hard_interference", "PresenceGateHardMean"),
    ):
        numbers.add(
            prefix,
            100 * float(gate_distribution["aggregate"][split]["mean_of_seed_means"]),
            source=presence_gate_distribution,
            selector=f"aggregate.{split}.mean_of_seed_means",
            evidence_class="exploratory",
            unit="%",
            precision=3,
        )

    sidecar_a5 = ZC / "csv" / "tier2_iq_sidecar_v1_vs_a5.csv"
    sidecar_mcldnn = ZC / "csv" / "tier2_iq_sidecar_v1_vs_mcldnn.csv"
    sidecar_iqformer = ZC / "csv" / "tier2_iq_sidecar_v1_vs_iqformer.csv"
    add_tier2_contrast("SidecarCleanVsAFive", sidecar_a5, "clean_retention")
    add_tier2_contrast("SidecarHardVsAFive", sidecar_a5, "hard_interference")
    add_tier2_contrast("SidecarHardVsMcldnn", sidecar_mcldnn, "hard_interference")
    add_tier2_contrast("SidecarHardVsIqformer", sidecar_iqformer, "hard_interference")
    add_tier2_contrast("SidecarSevereVsMcldnn", sidecar_mcldnn, "hard_interference_sir_minus15")
    add_tier2_contrast("SidecarSevereVsIqformer", sidecar_iqformer, "hard_interference_sir_minus15")

    capacity_m_s = ZC / "csv" / "tier2_capacity_M_v2_vs_a5.csv"
    capacity_l_s = ZC / "csv" / "tier2_capacity_L_v1_vs_S.csv"
    capacity_l_m = ZC / "csv" / "tier2_capacity_L_v1_vs_M.csv"
    capacity_l_mcldnn = ZC / "csv" / "tier2_capacity_L_v1_vs_mcldnn.csv"
    capacity_l_iqformer = ZC / "csv" / "tier2_capacity_L_v1_vs_iqformer.csv"
    add_tier2_contrast("CapacityMHardVsS", capacity_m_s, "hard_interference")
    add_tier2_contrast("CapacityMCleanVsS", capacity_m_s, "clean_retention")
    add_tier2_contrast("CapacityLHardVsS", capacity_l_s, "hard_interference")
    add_tier2_contrast("CapacityLCleanVsS", capacity_l_s, "clean_retention")
    add_tier2_contrast("CapacityLHardVsM", capacity_l_m, "hard_interference")
    add_tier2_contrast("CapacityLHardVsMcldnn", capacity_l_mcldnn, "hard_interference")
    add_tier2_contrast("CapacityLHardVsIqformer", capacity_l_iqformer, "hard_interference")
    add_tier2_contrast("CapacityLSevereVsIqformer", capacity_l_iqformer,
                       "hard_interference_sir_minus15")

    for key, run_dir in (
        ("SidecarParameters", "tier2_iq_sidecar_v1"),
        ("CapacityMParameters", "tier2_capacity_M_v2"),
        ("CapacityLParameters", "tier2_capacity_L_v1"),
    ):
        run_path = REPO / "artifacts" / run_dir / "run.json"
        with open(run_path, encoding="utf-8") as handle:
            tier2_run = json.load(handle)
        parameters = int(tier2_run["results"][0]["complexity"]["parameters"])
        numbers.add(key, parameters, source=run_path,
                    selector="results[0].complexity.parameters",
                    evidence_class="exploratory", precision=0)

    return numbers


def emit(numbers: Numbers) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    record = {
        "schema": "tvt_paper_numbers_v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "policy": (
            "every manuscript number must resolve to a key in this file; hand-typed numbers are a "
            "build failure. Sealed and exploratory keys must be labelled as such in the text."
        ),
        "gate_status": {
            "scientific_evidence_passed": False,
            "submission_unlocked": False,
            "failed_gates": ["confirmatory_family_gate_failed", "clean_retention_gate_failed"],
        },
        "source_sha256": numbers.sources,
        "keys": numbers.entries,
    }
    with open(OUT / "paper_numbers.json", "w", encoding="utf-8") as handle:
        json.dump(record, handle, indent=2, ensure_ascii=False)

    lines = [
        "% Generated by paper_data_layer/build_paper_numbers.py -- do not edit by hand.",
        "% Every value carries an evidence class; see outputs/paper_numbers.json.",
        "",
    ]
    for key, entry in sorted(numbers.entries.items()):
        value = entry["value"]
        if isinstance(value, str):
            rendered = value
        elif entry["precision"] == 0:
            rendered = f"{int(round(float(value)))}"
        else:
            rendered = f"{float(value):.{entry['precision']}f}"
        lines.append(f"\\newcommand{{\\{key}}}{{{rendered}}}% {entry['evidence_class']}")
    with open(OUT / "paper_macros.tex", "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")

    counts: dict[str, int] = {}
    for entry in numbers.entries.values():
        counts[entry["evidence_class"]] = counts.get(entry["evidence_class"], 0) + 1
    print(f"keys: {len(numbers.entries)}  by class: {counts}")
    print(f"sources: {len(numbers.sources)}")
    print(f"-> {OUT / 'paper_numbers.json'}")
    print(f"-> {OUT / 'paper_macros.tex'}")


if __name__ == "__main__":
    emit(build())
